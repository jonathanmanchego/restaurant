window.Vue = require('vue');
const bus = new Vue();
export default bus;