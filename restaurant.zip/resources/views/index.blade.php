@extends('layout.public')

@section('content')
	<h1>APP</h1>
@endsection

