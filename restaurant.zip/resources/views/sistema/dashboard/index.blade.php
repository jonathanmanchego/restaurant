<h3 >INICIO</h3>        
<div class="row">
  <div class="col-sm-4 chart">
    <canvas id="myChart1" width="400" height="400"></canvas>
  </div>
  <div class="col-sm-4 chart">
    <canvas id="myChart2" width="400" height="400"></canvas>
  </div>
  <div class="col-sm-4 chart">
    <canvas id="myChart3" width="400" height="400"></canvas>
  </div>
</div>
