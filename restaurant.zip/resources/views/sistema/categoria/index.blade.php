@extends('layout.sistema')


@section('content')
	@include('partials.list_basic')
@endsection