@extends('layout.sistema')
@section('content')
	@include('partials.form_basic_edit')
@endsection