@extends('layout.sistema')
@section('content')
	@include('partials.form_basic_create')
@endsection