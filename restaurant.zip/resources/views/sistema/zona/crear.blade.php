@extends('layout.sistema')
@section('content')
	<ul class="list-group">
		<li class="list-group-item">Nombre: Zonas definidas para realizar delivery.</li>
	</ul>
	@include('partials.form_basic_create')
@endsection