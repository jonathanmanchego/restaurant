<?php

namespace restaurant\models;

use Illuminate\Database\Eloquent\Model;

class menu_usuario extends Model
{
    protected $table = "menu_usuario";
    public $timestamps = false;
}
