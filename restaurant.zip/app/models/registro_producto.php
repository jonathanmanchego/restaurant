<?php

namespace restaurant\models;

use Illuminate\Database\Eloquent\Model;

class registro_producto extends Model
{
    protected $table = "registro_producto";
    public $timestamps = false;

}
