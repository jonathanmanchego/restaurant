<?php

namespace restaurant\models;

use Illuminate\Database\Eloquent\Model;

class permiso_usuario extends Model
{
    protected $table = 'permiso_usuario';
    public $timestamps = false;
}
