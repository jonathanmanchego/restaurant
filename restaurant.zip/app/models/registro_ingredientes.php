<?php

namespace restaurant\models;

use Illuminate\Database\Eloquent\Model;

class registro_ingredientes extends Model
{
    protected $table = "registro_ingredientes";
    public $timestamps = false;
}
