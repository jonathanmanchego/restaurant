<?php $__env->startSection('content'); ?>
	<div class="container-crud">
		<?php if(session('confirmacion')): ?>
			<div class="alert alert-success alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<ul>
					<li><?php echo e(session('confirmacion')); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		
		<div class="opciones">
			<a class="btn btn-primary" href="<?php echo e(url('/sistema'.$action.'/create')); ?>" role="button">
				<i class="fas fa-plus"></i><span>NUEVO</span>
			</a>
		</div>
		<?php if(!empty($data[0])): ?>
		<div class="listado">
			<div class="listado-headers">
				<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="listado-header-item">
						<span><?php echo e(strtoupper($header)); ?></span>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-header-item">
					<span>VER/EDITAR</span>
				</div>
			</div>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-item">
					<div class="listado-item-ele">
						<span><?php echo e($ele->id); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->nombre); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->tipo->nombre); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->celular); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->username); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->doc->nombre); ?> : <?php echo e($ele->nrodocumento); ?></span>
					</div>
					<div class="listado-item-ele"><a href="<?php echo e('\sistema'.$action.'/'.$ele->id); ?>/edit"><i class="far fa-edit"></i></a></div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/empleados/index.blade.php ENDPATH**/ ?>