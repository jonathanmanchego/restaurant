<?php $__env->startSection('content'); ?>
<div class="page-header" style="background-color: rgba(0, 0, 0, 0.6); background-image: url(/img/bannertest.jpg); text-shadow: black 1px 1px 5px; background-position: 50% -7.4px;" >
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1>Perfil</h1>
            </div>
        </div>
    </div>
</div>
<div class="container">
<br><br>
    <div class="row">   
    <?php if(session('fail')): ?>
    <div class="alert alert-danger "><?php echo e(session('fail')); ?></div>
    <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-sm-2">
            <i class="fa fa-fw fa-user fa-5x"></i>
        </div>
        <div class="col-sm-10">
        
            <form method="POST" action="">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="row col-md-6">
                        <label for="nombre" class="col-md-3 col-form-label"><?php echo e(__('Nombres')); ?></label>
                        <div class="col-md-9">
                            <input id="nombre" type="text" class="form-control" name="nombre" value="<?php echo e(Auth::user()->nombre); ?>" autofocus>
                        </div>
                    </div>
                    <div class="row col-md-6">
                        <label for="apellido" class="col-md-3 col-form-label"><?php echo e(__('Apellidos')); ?></label>
                        <div class="col-md-9">
                            <input id="apellido" type="text" class="form-control" name="apellido" value="<?php echo e(Auth::user()->apellido); ?>" autofocus>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="row col-md-12">
                        <label for="nombre" class="col-md-1 col-form-label"><?php echo e(__('E-mail')); ?></label>
                        <div class="col-md-10">
                            <input id="nombre" type="text" class="form-control" name="nombre" value="<?php echo e(Auth::user()->nombre); ?>@gmail.com" autofocus>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="row col-md-6">
                        <label for="telefono" class="col-md-3 col-form-label"><?php echo e(__('Telefono')); ?></label>
                        <div class="col-md-9">
                            <input id="telefono" type="text" class="form-control" name="telefono" value="<?php echo e(Auth::user()->telefono); ?>" autofocus>
                        </div>
                    </div>
                    <div class="row col-md-6">
                        <label for="celular" class="col-md-3 col-form-label"><?php echo e(__('Celular')); ?></label>
                        <div class="col-md-9">
                            <input id="celular" type="text" class="form-control" name="celular" value="<?php echo e(Auth::user()->celular); ?>" autofocus>
                    </div>
                </div>
                </div>
                
                <div class="form-group row">
                    <div class="row col-md-6">
                        <label for="zona" class="col-md-3 col-form-label"><?php echo e(__('Zona')); ?></label>
                        <div class="col-md-9">
                            <select name="zona" id="zona" class="form-control">
                                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($zona['id'] == Auth::user()->zonas_id ): ?>
                                        <option selected value="<?php echo e($zona['id']); ?>"><?php echo e($zona['nombre']); ?></option>
                                    <?php endif; ?>
                                    <?php if($zona['id'] != Auth::user()->zonas_id): ?>
                                        <option value="<?php echo e($zona['id']); ?>"><?php echo e($zona['nombre']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row col-md-6">
                        <label for="direccion" class="col-md-3 col-form-label"><?php echo e(__('Dirección')); ?></label>
                        <div class="col-md-9">
                            <input id="direccion" type="text" class="form-control" name="direccion" value="<?php echo e(Auth::user()->direccion); ?>" autofocus>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="row col-md-6">
                        <label for="tipo_documento" class="col-md-3 col-form-label"><?php echo e(__('Tipo Documento')); ?></label>

                        <div class="col-md-9">
                            <select name="tipo_documento" id="tipo_documento" class="form-control <?php if ($errors->has('tipo_documento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipo_documento'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                <?php $__currentLoopData = $tipo_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipo_doc['id']); ?>"><?php echo e($tipo_doc['nombre']); ?></option>
                                        <?php if($zona['id'] == Auth::user()->zonas_id ): ?>
                                        <option selected value="<?php echo e($tipo_doc['id']); ?>"><?php echo e($tipo_doc['nombre']); ?></option>
                                    <?php endif; ?>
                                    <?php if($zona['id'] != Auth::user()->zonas_id): ?>
                                        <option value="<?php echo e($tipo_doc['id']); ?>"><?php echo e($tipo_doc['nombre']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row col-md-6">
                        <label for="nrodocumento" class="col-md-3 col-form-label"><?php echo e(__('N° Doc.')); ?></label>
                        <div class="col-md-9">
                            <input id="nrodocumento" type="text" class="form-control" name="nrodocumento" value="<?php echo e(Auth::user()->nrodocumento); ?>"  autocomplete="nrodocumento" autofocus>
                        </div>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-lg-8 mx-auto">
                        <button type="submit" class=" w-100 btn btn-primary">
                            <?php echo e(__('Guardar')); ?>

                        </button>
                    </div>
                </div>
            </form>
            <br>
            <div class="form-group row ">
                <div class="col-lg-8 mx-auto">
                    <button type="submit" type="button" class="w-100 btn btn-link" data-toggle="modal" data-target="#myModal">
                        <?php echo e(__('Cambiar Contraseña')); ?> 
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title">Cambiar Contraseña</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
                
        </div>
        <form method="POST" action="">
            <div class="modal-body">
                <label for="password"><?php echo e(__('Contraseña Actual')); ?></label>
                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value=""  autocomplete="password" autofocus>
                
                <label for="newpassword"><?php echo e(__('Nueva Contraseña')); ?></label>
                <input id="newpassword" type="password" class="form-control " name="password" value="" >

                <label for="repassword"><?php echo e(__('Repetir Nueva Contraseña')); ?></label>
                <input id="repassword" type="password" class="form-control " name="password" value="" >
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" ><?php echo e(__('Guardar')); ?></button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            </div>
        </form>
        </div>

    </div>
</div><br><br>
<!-- end modal-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/general/usuario/profile.blade.php ENDPATH**/ ?>