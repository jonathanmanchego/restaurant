<?php $__env->startSection('content'); ?>
	<div class="container-crud">
	<?php if($errors->any()): ?>
		<div class="alert alert-warning alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
			</ul>
		</div>
	<?php endif; ?>
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	<div class="form-group">
		    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
		    <input id="<?php echo e($head); ?>Input" class="form-control" type="<?php if(isset($tipos[$key])): ?><?php echo e($tipos[$key]); ?><?php else: ?> text <?php endif; ?>" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> >
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="form-group">
		    <label for="estado">ESTADO</label>
		    <select class="form-control" name="estado_mesas_id" id="estado">
				<?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
					<option value="<?php echo e($est->id); ?>"><?php echo e($est->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		</div>
		<div class="form-group">
				<label for="ambiente">AMBIENTE</label>
				<select class="form-control" name="ambiente_id" id="ambiente">
					<?php $__currentLoopData = $ambientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
						<option value="<?php echo e($amb->id); ?>"><?php echo e($amb->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
		</div>
		
		<button type="submit" class="btn btn-primary">GUARDAR</button>
	</form>
</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/mesa/crear.blade.php ENDPATH**/ ?>