<?php $__env->startSection('content'); ?>
	<div class="container-crud">
	<?php if($errors->any()): ?>
		<div class="alert alert-warning alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
			</ul>
		</div>
	<?php endif; ?>
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	<div class="form-group">
		    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
		    <input id="<?php echo e($head); ?>Input" class="form-control" type="<?php if(isset($tipos[$key])): ?><?php echo e($tipos[$key]); ?><?php else: ?> text <?php endif; ?>" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> >
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="form-group">
		    <label for="tipo_documento">Tipo Documento</label>
		    <select class="form-control" name="tipo_documento" id="tipo_documento">
				<?php $__currentLoopData = $tiposDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
					<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		</div>
		<div class="form-group">
		    <label for="documentoInput"><?php echo e(strtoupper('N° Documento')); ?></label>
		    <input id="documentoInput" class="form-control" type="text" name="nrodocumento" placeholder="Documento" >
		</div>
		<div class="form-group">
		    <label for="TipoEmp">Tipo Empleados</label>
		    <select class="form-control" name="tipo_empleado" id="TipoEmp">
				<?php $__currentLoopData = $tiposEmpleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
					<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		</div>
		<div class="form-group">
		    <label for="zona_">Zona</label>
		    <select class="form-control" name="zona_" id="zona_">
				<?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
					<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		</div>
		
		<button type="submit" class="btn btn-primary">GUARDAR</button>
	</form>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/empleados/crear.blade.php ENDPATH**/ ?>