<?php $__env->startSection('content'); ?>
<div class="page-header" style="background-color: rgba(0, 0, 0, 0.6); background-image: url(/img/bannertest.jpg); text-shadow: black 1px 1px 5px; background-position: 50% -7.4px;" >
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1></h1>
            </div>
        </div>
    </div>
</div><br><br>
<div class="container">
<div class="row">
    <div class="col-sm-3 col-md-3 col-lg-3 text-center">
        
        <select class="form-control" id="sel1">
            <option value="">TODO</option>
            <option value="">ENTRADAS</option>
            <option value="">POSTRES</option>
            <option value="">PLATOS</option>
            <option value="">BEBIDAS</option>
        </select>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-6 text-center"> 
        <input type="text" class="form-control" id="in-buscar" placeholder="Buscar en Carta">
    </div>
    <div class="col-sm-2 col-md-2 col-lg-2 text-center"> 
        <button  class="btn btn-warning form-control" id="btn-buscar"><i class="fa fa-search" aria-hidden="true"></i>
</button>
    </div>
    <div class="col-sm-1 col-md-1 col-lg-1 text-center"> 
        <a class="btn btn-danger" href="<?php echo e(route('Carrito')); ?>"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i></a>
    </div>
</div>
    <div class="row mr-md-2 justify-content-justify">
        <?php if($data): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 ">
                    <div class="card mr-1 my-2 border-dark">
                        
                            <img src="<?php echo e(url('/uploads/'.$item->imagen)); ?>" alt="" class="img-card-top">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->nombre); ?></h5>
                            <p class="card-text">
                                <?php echo e($item->descripcion); ?>

                            </p>
                            <p>
                                <span>Precio</span>
                                <span>S/.<?php echo e(number_format($item->precio,2,".",",")); ?></span>
                            </p>
                            <a href="<?php echo e(route('productoMostrar',['id' => $item->id])); ?>" class="btn btn-info">
                                <?php echo e(__('Detalles')); ?>

                            </a>
                            <a href="<?php echo e(route('addToCar',['producto' => $item->id,'cantidadAdd' => 1])); ?>" class="btn btn-warning">
                            <?php echo e(__('Comprar')); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <div class="cold-md-1"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/productos/productos.blade.php ENDPATH**/ ?>