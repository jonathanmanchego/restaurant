<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo e(config('app.name')); ?></title>
	
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/all.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/css_boot/bootstrap.css')); ?>">
	<script type="text/javascript" src="<?php echo e(url('/js/js_boot/bootstrap.min.js')); ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/app.css')); ?>">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?php echo e(url('/css/fontawesome-free-5.10.2-web/css/all.min.css')); ?>">
    <script src="https://kit.fontawesome.com/db71cea23f.js"></script>
</head>
<body>
	<div class="wrapp" id="app">
		<nav class="navbar navbar-expand-lg navbar-light wrapp_nav">
			<div class="logo-space ">
				<img src="/img/logoPrincipal.png">
			</div>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>
			<div class="collapse navbar-collapse" id="navbarNavDropdown">
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>"><span>INICIO</span></a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/productos')); ?>"><span>PRODUCTOS</span></a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/articulos')); ?>"><span>ARTÍCULOS</span></a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/contacto')); ?>"><span>CONTACTO</span></a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo e(url('/nosotros')); ?>"><span>NOSOTROS</span></a></li>
				<li class="nav-item"><a class="nav-link toBuy"  href="<?php echo e(route('Carrito')); ?>"><i class="far fa-clipboard"></i>&nbsp;</a></li>
			
				<!-- Authentication Links -->
				<?php if(auth()->guard()->guest()): ?>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
					</li>
					<?php if(Route::has('register')): ?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
						</li>
					<?php endif; ?>
				<?php else: ?>
					<li class="nav-item dropdown">
						<a id="navbarDropdown"  class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<?php echo e(Auth::user()->nombre); ?><span class="caret"></span>
						</a>

						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Perfil')); ?></a>
							<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
							   onclick="event.preventDefault();
											 document.getElementById('logout-form').submit();">
								<?php echo e(__('Logout')); ?>

							</a>

							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo csrf_field(); ?>
							</form>
						</div>
					</li>
				<?php endif; ?>
			</ul>
			</div>
		</nav>
		
		<?php $__env->startSection('slider-carousel'); ?>
		<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
		  <div class="carousel-inner">
		  	<?php if(isset($sli)): ?>
		  	<?php $__currentLoopData = $sli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <div class="carousel-item <?php if($key == 0): ?> active <?php endif; ?>">
		      <img src="<?php echo e(url('/img/slider/'.$s->nombre)); ?>" class="d-block w-100" alt="">
		    </div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    <?php endif; ?>
		  </div>
		  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
		    <span class="carousel-control-prev-icon arrow" aria-hidden="true "></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
		    <span class="carousel-control-next-icon arrow" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>
		<?php echo $__env->yieldSection(); ?>
		
		<div class="wrapp-content" >
			<?php if(session('success')): ?>
                <div class="alert alert-success "><?php echo e(session('success')); ?></div>
            <?php endif; ?>
			<div class="container mt-3">
			<?php $__env->startSection('content'); ?>
				<?php echo $__env->yieldSection(); ?>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo e(url('/js/jquery-3.4.1.min.js')); ?>"></script>
	<script src="<?php echo e(url('/js/customs/helper.js')); ?>"></script>
	<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
	<br><br>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<img src="/img/logo.png">
				</div>
				<div class="col-sm-4">
					<ul class="list-group">
						<li class="list-group-item style-1"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/productos')); ?>">Productos</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/articulos')); ?>">Artículos</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/contacto')); ?>">Contacto</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/nosotros')); ?>">Nosotros</a></li>
					</ul>
				</div>
				<div class="col-sm-4">
					<ul class="list-group">
						<li class="list-group-item style-1 list-group-label"><h3>SÍGUENOS EN :</h3></li>
						<li class="list-group-item style-1"><a href="#">Facebook <i class="fab fa-facebook-f"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Twitter <i class="fab fa-twitter"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Instagram <i class="fab fa-instagram"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Youtube <i class="fab fa-youtube"></i></a></li>
					</ul>
				</div>
				</div>
			</div>
		</div>
	</footer>
</body>
</html><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/layout/public.blade.php ENDPATH**/ ?>