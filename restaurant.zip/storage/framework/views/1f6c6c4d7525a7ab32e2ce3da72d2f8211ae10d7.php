<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
		<div class="col-md-5">
			<label>Ambiente:</label>&nbsp;
			<select class="form-control" name="ambiente" id="selectAmbiente" onchange="cambiarCanvas()">
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<option value="<?php echo e($ele->id); ?>"><?php echo e($ele->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="col-md-3">
			<label>&nbsp;</label>
			<a  class="btn btn-success form-control"  href="<?php echo e(url('/sistema/ordenes/agregar')); ?>">Hacer Pedido</a>
		</div>
    </div>
</div><br><br>
<div id="nombre_ambiente"></div>
	<canvas width="800" height="550" id="lienzo"></canvas><br>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('/js/customs/mesa/view.js')); ?>"></script>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/mesa/show-mesa.blade.php ENDPATH**/ ?>