<?php $__env->startSection('content'); ?>
	<div class="container-crud">
		<?php if(session('confirmacion')): ?>
			<div class="alert alert-success alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<ul>
					<li><?php echo e(session('confirmacion')); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		
		<div class="opciones">
			<a class="btn btn-primary btn-block" href="<?php echo e(url('/sistema'.$action.'/create')); ?>" role="button">
				<i class="fas fa-plus"></i><span>NUEVO</span>
			</a>
			
		</div>
		<?php if(!empty($data[0])): ?>
		<div class="listado">
			<div class="listado-headers">
				<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="listado-header-item">
						<span><?php echo e(strtoupper($header)); ?></span>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-header-item">
					<span>VER/EDITAR</span>
				</div>
				<div class="listado-header-item">
					<span>ACTIVAR</span>
				</div>
			</div>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-item" >
					<div class="listado-item-ele">
						<span><?php echo e($ele->id); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->version); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->fecha); ?></span>
					</div>
					<div class="listado-item-ele" >
						<span id="cartaEstado<?php echo e($ele->id); ?>" data-id="<?php echo e($ele->id); ?>" <?php if($ele->estado == 1): ?> data-name="activa"> <b>ACTIVA</b> <?php else: ?> data-name="inactiva" > INACTIVA <?php endif; ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->tipo->nombre); ?></span>
					</div>
					<div class="listado-item-ele"><a href="<?php echo e('\sistema'.$action.'/'.$ele->id); ?>/edit"><i class="far fa-edit"></i></a></div>
					<div class="listado-item-ele" id="carta<?php echo e($ele->id); ?>">
						<?php if($ele->estado == 0): ?> 
							<button class="btn btn-info btn-activate"  onclick="javascript:changeEstado(<?php echo e($ele->id); ?>)">
							ACTIVAR
							</button>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>
	</div>
	<div class="container-crud">
		<div class="opciones">
			<a class="btn btn-primary btn-block" data-toggle="modal" data-target="#modal-default1" ><span class="fa fa-list"></span>  INSTANCIAR</a>
		</div>
		<div class="box-body">
				
				<table class="table table-bordered table-hover dataTable" id="tabla-data-productos">
					<thead>                    	
						<tr>
								<th>#</th>
								<th>PRODUCTO</th>
								<th>CODIGO PRODUCTO</th>
								<th>STOCK</th>
								<th>PRECIO</th>
								<th>CATEGORIA</th>
								<th>Quitar</th>
						</tr>                
					</thead>
					<tbody id="carta_items">
						<?php $__currentLoopData = $carta_activa->getProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr id="ele-carta-item-<?php echo e($items->id); ?>">
							
							<td><?php echo e($items->id); ?></td>
							<td><?php echo e($items->nombre); ?></td>
							<td><?php echo e($items->codigo); ?></td>
							<td>
								<input type="number" class="borde border-secondary text-center form-control-plaintext" id="counter_<?php echo e($items->id); ?>" autocomplete="off" style="width:35%" value="<?php echo e($productos_actual[$key]->stock); ?>">
							</td>
							<td>
								<?php echo e(number_format($items->precio,2)); ?>

							</td>
							<td>
								<?php echo e($items->categoria->nombre); ?>

							</td>
							<td>
								<button class="btn btn-danger" onclick="eliminarProd(<?php echo e($items->id); ?>)"><span class="fa fa-close"></span></button>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
					</tbody>
				</table>
			</div>
	</div>
	<div class="col-xs-12">
		<div class="text-center">
			<button  type="button" class="btn btn-success" onclick="guardarPedido()">Guardar</button>
		</div>
	</div>
	<?php echo $__env->make('sistema.carta.modal-producto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.scripts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(url('/js/customs/carta/script.js')); ?>"></script>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/carta/index.blade.php ENDPATH**/ ?>