  <ul class="dropdown-menu">
    <!-- The user image in the menu -->
    <li class="user-header">
      <img src="/img/avatar2.png" class="img-circle" alt="<?php echo e(Auth::user()->nombre); ?>">
      <p>
        <?php echo e(Auth::user()->nombre . ' ' .Auth::user()->apellido); ?>

      </p>
    </li>
    <!-- Menu Body -->
    <li class="user-body">
      <div class="row">
        <div class="col-xs-4 text-center">
          <a href="#">Tareas</a>
        </div>
        <div class="col-xs-4 text-center">
          <a href="#">Horario</a>
        </div>
        <div class="col-xs-4 text-center">
          <a href="#">Reuniones</a>
        </div>
      </div>
      <!-- /.row -->
    </li>
    <!-- Menu Footer-->
    <li class="user-footer">
      <div class="float-left">
        <a href="#" class="btn btn-default btn-flat">Profile</a>
      </div>
      <div class="float-right">
        <a class="btn btn-default btn-flat" href="#"
           onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
            <?php echo e(__('Salir')); ?>

        </a>

        <form id="logout-form" action="<?php echo e(route('sistema::sis-logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
      </div>
    </li>
  </ul><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/partials/user-info/drop-user.blade.php ENDPATH**/ ?>