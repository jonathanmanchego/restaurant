<?php $__env->startSection('content'); ?>
	<div class="container-crud">
	
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	<div class="form-group">
		    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
		    <input id="<?php echo e($head); ?>Input" value="<?php echo e(old($head)); ?>" class="form-control" type="<?php if(isset($tipos[$key])): ?><?php echo e($tipos[$key]); ?><?php else: ?> text <?php endif; ?>" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> >
		</div>
		<?php if ($errors->has($head)) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first($head); ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($message); ?></strong>
				</span>
		<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<button type="submit" class="btn btn-primary">GUARDAR</button>
	</form>
</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/ambiente/crear.blade.php ENDPATH**/ ?>