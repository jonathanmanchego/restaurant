<?php $__env->startSection('content'); ?>
<?php if(!empty($mesaGlobal)): ?>
<tabla-orden></tabla-orden>
<?php else: ?>
    <div class="col-lg-12">
        <a class="btn btn-primary" href="<?php echo e(url('/sistema/mesas-show')); ?>">Seleccionar Mesa</a>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('partials.scripts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('/js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/orden/crear.blade.php ENDPATH**/ ?>