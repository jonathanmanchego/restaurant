<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo e(config('app.name')); ?></title>
	
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/all.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/css_boot/bootstrap.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/app.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('/css/admin/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
   
   
</head>
<body>
	<div class="wrapp">
		<nav class="wrapp_nav">
			<div class="logo-space">
				<img src="/img/logo.png">
			</div>
          
			<ul>
				<li><a href="<?php echo e(url('/')); ?>"><span>INICIO</span></a></li>
				<li><a href="<?php echo e(url('/productos')); ?>"><span>PRODUCTOS</span></a></li>
				<li><a href="<?php echo e(url('/articulos')); ?>"><span>ARTÍCULOS</span></a></li>
				<li><a href="<?php echo e(url('/contacto')); ?>"><span>CONTACTO</span></a></li>
				<li><a href="<?php echo e(url('/nosotros')); ?>"><span>NOSOTROS</span></a></li>
				<li> <a class="toBuy" href="<?php echo e(route('Carrito')); ?>"><span><i class="fa fa-shopping-cart" aria-hidden="true" ></i></span></a>
                </li>
			
				<!-- Authentication Links -->
				<?php if(auth()->guard()->guest()): ?>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
					</li>
					<?php if(Route::has('register')): ?>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
						</li>
					<?php endif; ?>
				<?php else: ?>
					<li class="nav-item dropdown">
						<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
							<?php echo e(Auth::user()->nombre); ?> <span class="caret"></span>
						</a>

						<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
							<a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><?php echo e(__('Perfil')); ?></a>
							<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
							   onclick="event.preventDefault();
											 document.getElementById('logout-form').submit();">
								<?php echo e(__('Logout')); ?>

							</a>

							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo csrf_field(); ?>
							</form>
						</div>
					</li>
				<?php endif; ?>
			</ul>
		</nav>
		
		<div class="wrapp-content">
			<?php if(session('success')): ?>
                <div class="alert alert-success "><?php echo e(session('success')); ?></div>
            <?php endif; ?>
			<div class="container mt-3">
			<?php $__env->startSection('content'); ?>
				<?php echo $__env->yieldSection(); ?>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="<?php echo e(url('/js/jquery-3.4.1.min.js')); ?>"></script>
	<script src="<?php echo e(url('/js/customs/helper.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('/js/js_boot/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
					<img src="/img/logo.png">
				</div>
				<div class="col-sm-4">
					<ul class="list-group">
						<li class="list-group-item style-1"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/productos')); ?>">Productos</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/articulos')); ?>">Artículos</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/contacto')); ?>">Contacto</a></li>
						<li class="list-group-item style-1"><a href="<?php echo e(url('/nosotros')); ?>">Nosotros</a></li>
					</ul>
				</div>
				<div class="col-sm-4">
					<ul class="list-group">
						<li class="list-group-item style-1 list-group-label"><h3>SÍGUENOS EN :</h3></li>
						<li class="list-group-item style-1"><a href="#">Facebook <i class="fa fa-facebook"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Twitter <i class="fa fa-twitter"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Instagram <i class="fa fa-instagram"></i></a></li>
						<li class="list-group-item style-1"><a href="#">Youtube <i class="fa fa-youtube"></i></a></li>
					</ul>
				</div>
				</div>
			</div>
		</div>
	</footer>
</body>
</html><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/layout/public-noslider.blade.php ENDPATH**/ ?>