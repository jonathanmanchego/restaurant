<div class="container-crud">
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
			<?php echo csrf_field(); ?>
		    <?php echo method_field('PUT'); ?>
			<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<div class="form-group">
				    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
				    <input id="<?php echo e($head); ?>Input" class="form-control" type="text" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> value="<?php echo e($data->$head); ?>">
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  
		  <button type="submit" class="btn btn-primary">GUARDAR</button>
		  <button form="del" type="submit" class="btn btn-danger">ELIMINAR</button>
	</form>
	<form id="del" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php echo method_field('DELETE'); ?>
	</form>
</div>
<?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/partials/form_basic_edit.blade.php ENDPATH**/ ?>