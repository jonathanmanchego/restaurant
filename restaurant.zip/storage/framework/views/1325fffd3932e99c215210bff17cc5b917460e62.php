<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mr-md-2 justify-content-center">
        <?php if($dato): ?>
            <div class="card mr-3 w-100 border-dark">
                
                <div class="row no-gutters">
                	<div class="col-md-4">
                    	<img src="<?php echo e(url('/uploads/'.$dato->imagen)); ?>" alt="" class="card-img">
                	</div>
                	<div class="col">
	                    <div class="card-body text-center">
	                        <h4 class="card-title mr-auto"><?php echo e($dato->nombre); ?></h4>
                            <p class="card-text">
                                <?php echo e($dato->descripcion); ?>

                            </p>
	                        <ul class="list-group list-group-flush">
							    <li class="list-group-item">S/.<?php echo e(number_format($dato->precio,2,".",",")); ?></li>
							    
						  	</ul>
	                        
	                    </div>
                	</div>
                    <div class="card-footer text-center col-md-12 text-muted">
                    	<a href="<?php echo e(route('addToCar',['producto' => $dato->id,'cantidadAdd' => 1])); ?>" class=" w-75 btn btn-primary">
                            <?php echo e(__('Añadir Compra')); ?>

                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/productos/producto.blade.php ENDPATH**/ ?>