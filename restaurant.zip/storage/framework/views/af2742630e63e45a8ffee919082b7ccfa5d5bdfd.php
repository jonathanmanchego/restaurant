<div class="modal fade" id="modal-default1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Lita de Productos</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-9">
                        <input type="text" style="text-transform:uppercase;" class="form-control" id="buscarprod">
                    </div>
                    <div class="col-md-3">
                        
                                    <button id="btn-agregar" type="button" class="btn btn-success btn-flat btn-block"><span class="fa fa-plus"></span> Agregar</button>
                    </div>                                           
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table id="example1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Codigo</th>
                                    <th>Nombre</th>
                                    <th>Precio</th>
                                    
                                    <th>Categoria</th>
                                    <th>Agregar</th>
                                </tr>
                            </thead>
                            <tbody id="busqueda_producto">
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $aux = 0 ?>
                                    <?php $__currentLoopData = $carta_activa->getProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($producto->id != $list->id): ?>
                                            <?php $aux++ ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($aux == count($carta_activa->getProductos)): ?>
                                        <tr id="item-productos-<?php echo e($producto->id); ?>">
                                            <td><?php echo e($producto->id); ?></td>
                                            <td><?php echo e($producto->codigo); ?></td>
                                            <td><?php echo e($producto->nombre); ?></td>
                                            <td><?php echo e(number_format($producto->precio, 2)); ?> </td>
                                            
                                            <td><?php echo e($producto->categoria->nombre); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button class="btn btn-success" id="btn-agregarprod" onclick="agregarProd(this)" data-id="<?php echo e($producto->id); ?>"data-codigo="<?php echo e($producto->codigo); ?>" data-nombre="<?php echo e($producto->nombre); ?>" data-categoria="<?php echo e($producto->categoria->nombre); ?>" data-precio="<?php echo e(number_format($producto->precio, 2)); ?>">
                                                        <span class="fa fa-plus"></span>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
    <?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/carta/modal-producto.blade.php ENDPATH**/ ?>