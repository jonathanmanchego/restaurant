<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md">
            <div class="card bg-secondary text-white">
                <div class="card-header"><?php echo e(__('Registro')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                                <div class="col-md-8">
                                    <input id="nombre" type="text" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e(old('nombre')); ?>"  autocomplete="nombre" autofocus>

                                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Apellido')); ?></label>

                                <div class="col-md-8">
                                    <input id="apellido" type="text" class="form-control <?php if ($errors->has('apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('apellido'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="apellido" value="<?php echo e(old('apellido')); ?>"  autocomplete="apellido" autofocus>

                                    <?php if ($errors->has('apellido')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('apellido'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Usuario')); ?></label>

                                <div class="col-md-8">
                                    <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>"  autocomplete="username" autofocus>

                                    <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                                <div class="col-md-8">
                                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="<?php echo e(old('password')); ?>"  autocomplete="password" autofocus>

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="tipo_documento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo Documento')); ?></label>

                                <div class="col-md-8">
                                    <select name="tipo_documento" id="tipo_documento" class="form-control <?php if ($errors->has('tipo_documento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipo_documento'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <?php $__currentLoopData = $tipo_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tipo_doc['id']); ?>"><?php echo e($tipo_doc['nombre']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    

                                    <?php if ($errors->has('tipo_documento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tipo_documento'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <label for="nrodocumento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('N° Documento')); ?></label>

                                <div class="col-md-8">
                                    <input id="nrodocumento" type="text" class="form-control <?php if ($errors->has('nrodocumento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nrodocumento'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nrodocumento" value="<?php echo e(old('nrodocumento')); ?>"  autocomplete="nrodocumento" autofocus>

                                    <?php if ($errors->has('nrodocumento')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nrodocumento'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="correo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-mail')); ?></label>

                                <div class="col-md-8">
                                    <input id="correo" type="email" class="form-control <?php if ($errors->has('correo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('correo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="correo" value="<?php echo e(old('correo')); ?>"  autocomplete="correo" autofocus>

                                    <?php if ($errors->has('correo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('correo'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Teléfono')); ?></label>

                                <div class="col-md-8">
                                    <input id="telefono" type="text" class="form-control <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telefono" value="<?php echo e(old('telefono')); ?>"  autocomplete="telefono" autofocus>

                                    <?php if ($errors->has('telefono')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telefono'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <label for="celular" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>

                                <div class="col-md-8">
                                    <input id="celular" type="text" class="form-control <?php if ($errors->has('celular')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('celular'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="celular" value="<?php echo e(old('celular')); ?>"  autocomplete="celular" autofocus>

                                    <?php if ($errors->has('celular')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('celular'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="row col-md-6">
                                <label for="direccion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Dirección')); ?></label>

                                <div class="col-md-8">
                                    <input id="direccion" type="text" class="form-control <?php if ($errors->has('direccion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('direccion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="direccion" value="<?php echo e(old('direccion')); ?>"  autocomplete="direccion" autofocus>

                                    <?php if ($errors->has('direccion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('direccion'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="row col-md-6">
                                <label for="zona" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Zonas')); ?></label>

                                <div class="col-md-8">
                                    <select name="zona" id="zona" class="form-control <?php if ($errors->has('zona')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zona'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zona['id']); ?>"><?php echo e($zona['nombre']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    

                                    <?php if ($errors->has('zona')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zona'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-8 mx-auto">
                                <button type="submit" class=" w-100 btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/auth/register.blade.php ENDPATH**/ ?>