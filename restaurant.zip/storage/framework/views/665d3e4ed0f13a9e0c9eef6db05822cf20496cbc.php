<?php $__env->startSection('content'); ?>
	<div class="container-crud">
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
			<?php echo csrf_field(); ?>
		    <?php echo method_field('PUT'); ?>
			<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  	<div class="form-group">
				    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
				    <input id="<?php echo e($head); ?>Input" class="form-control" type="text" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> value="<?php echo e($data->$head); ?>">
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="form-group">
			    <label for="estado">ESTADO</label>
			    <select class="form-control" name="estado_mesas_id" id="estado">
			    	<option value="<?php echo e($data->estado->id); ?>"><?php echo e($data->estado->nombre); ?></option>
					<?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
						<option value="<?php echo e($est->id); ?>"><?php echo e($est->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    </select>
			</div>
			<div class="form-group">
				<label for="ambiente">AMBIENTE</label>
				<select class="form-control" name="ambiente_id" id="ambiente">
					<?php $__currentLoopData = $ambientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
						<option value="<?php echo e($amb->id); ?>"><?php echo e($amb->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		  
		  <button type="submit" class="btn btn-primary">GUARDAR</button>
		  <button form="del" type="submit" class="btn btn-danger">ELIMINAR</button>
	</form>
	<form id="del" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php echo method_field('DELETE'); ?>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/mesa/editar.blade.php ENDPATH**/ ?>