<?php $__env->startSection('content'); ?>
<div class="page-header" style="background-color: rgba(0, 0, 0, 0.6); background-image: url(/img/bannertest.jpg); text-shadow: black 1px 1px 5px; background-position: 50% -7.4px;" >
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1>Artículos</h1>
            </div>
        </div>
    </div>
</div><br><br>
    <div class="container">
        <div class="row">
       
            <div class="col-sm-5">
                <img alt="" class="img-responsive img-thumbnail mar-v os-animation animated fadeInLeft" src="/img/nosotros.jpg" >
            </div>
            <div class="col-sm-7">
                <h2>TITULO DEL ARTÍCULO 03</h2>
                <span class="separator"></span>
                <p>Descripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineas</p>
                <br>
                <p>Martes, 21 de Agosto del 2019</p>
			</div>
        </div><br>
        <div class="row">
       
            <div class="col-sm-5">
                <img alt="" class="img-responsive img-thumbnail mar-v os-animation animated fadeInLeft" src="/img/nosotros.jpg" >
            </div>
            <div class="col-sm-7">
                <h2>TITULO DEL ARTÍCULO 02</h2>
                <span class="separator"></span>
                <p>Descripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineas</p>
                <br>
                <p>Martes, 20 de Agosto del 2019</p>
			</div>
        </div><br>
        <div class="row">
       
            <div class="col-sm-5">
                <img alt="" class="img-responsive img-thumbnail mar-v os-animation animated fadeInLeft" src="/img/nosotros.jpg" >
            </div>
            <div class="col-sm-7">
                <h2>TITULO DEL ARTÍCULO 01</h2>
                <span class="separator"></span>
                <p>Descripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineasDescripcion del tema en varias lineas</p>
                <br>
                <p>Martes, 19 de Agosto del 2019</p>
			</div>
        </div><br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/general/articulos.blade.php ENDPATH**/ ?>