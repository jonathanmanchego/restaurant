<?php $__env->startSection('content'); ?>
	<div class="container-crud">
	<?php if($errors->any()): ?>
		<div class="alert alert-warning alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
			</ul>
		</div>
	<?php endif; ?>
	<form class="form" action="<?php echo e(url('/sistema'.$action)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	<div class="form-group">
		    <label for="<?php echo e($head); ?>Input"><?php echo e(strtoupper($head)); ?></label>
		    <input id="<?php echo e($head); ?>Input" class="form-control" type="text" name="<?php echo e($head); ?>" placeholder="<?php echo e($head); ?>" <?php if($head == 'id'): ?> readonly <?php else: ?> <?php echo e(""); ?> <?php endif; ?> >
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="form-group">
		    <label for="TipoCarta">Tipo Carta</label>
		    <select class="form-control" name="tipoCarta" id="tCarta">
				<?php $__currentLoopData = $tiposCarta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	 
					<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		</div>
		
		<button type="submit" class="btn btn-primary">GUARDAR</button>
	</form>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/carta/crear.blade.php ENDPATH**/ ?>