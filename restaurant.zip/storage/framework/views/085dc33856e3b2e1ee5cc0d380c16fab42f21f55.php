<?php $__env->startSection('content'); ?>
	<div class="container-crud">
		<?php if(session('confirmacion')): ?>
			<div class="alert alert-success alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<ul>
					<li><?php echo e(session('confirmacion')); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		
		<div class="opciones">
			<a class="btn btn-primary btn-block" href="<?php echo e(url('/sistema'.$action.'/create')); ?>" role="button">
				<i class="fas fa-plus"></i><span>NUEVO</span>
			</a>
			
		</div>
		<?php if(!empty($data[0])): ?>
		<div class="listado">
			<div class="listado-headers">
				<?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="listado-header-item">
						<span><?php echo e(strtoupper($header)); ?></span>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-header-item">
					<span>VER/EDITAR</span>
				</div>
				<div class="listado-header-item">
					<span>ACTIVAR</span>
				</div>
			</div>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ele): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="listado-item" >
					<div class="listado-item-ele">
						<span><?php echo e($ele->id); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->version); ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->fecha); ?></span>
					</div>
					<div class="listado-item-ele" >
						<span id="cartaEstado<?php echo e($ele->id); ?>" data-id="<?php echo e($ele->id); ?>" <?php if($ele->estado == 1): ?> data-name="activa"> <b>ACTIVA</b> <?php else: ?> data-name="inactiva" > INACTIVA <?php endif; ?></span>
					</div>
					<div class="listado-item-ele">
						<span><?php echo e($ele->tipo->nombre); ?></span>
					</div>
					<div class="listado-item-ele"><a href="<?php echo e('\sistema'.$action.'/'.$ele->id); ?>/edit"><i class="far fa-edit"></i></a></div>
					<div class="listado-item-ele" id="carta<?php echo e($ele->id); ?>">
						<?php if($ele->estado == 0): ?> 
							<button class="btn btn-info btn-activate"  onclick="javascript:changeEstado(<?php echo e($ele->id); ?>)">
							ACTIVAR
							</button>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>
	</div>
	<div class="container-crud">
		<tabla-carta></tabla-carta>
	</div>
	
	<tabla-productos v-bind:titles="['#','Codigo','Nombre','Precio','Categoria','Agregar']" v-bind:ruta="'sistema/producto'"></tabla-productos>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.scripts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="<?php echo e(url('/js/app.js')); ?>" ></script>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('/js/customs/carta/script.js')); ?>"></script>

<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/carta/indexx.blade.php ENDPATH**/ ?>