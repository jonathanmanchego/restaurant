<?php $__env->startSection('content'); ?>
<div class="row">
    <?php if(!empty($mesaGlobal)): ?>
    <div class="col-lg-12">
        <div class="box box-danger">
            <div class="box-body">
                <div class="form-group row">
                                         
                    <div class="col-md-3">
                       
                        <?php $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mesa->id == $mesaGlobal): ?>
                                <input name="mesa" id="mesas" class="form-control" type="hidden" value="<?php echo e($mesa->id); ?>" readonly="readonly"></option>
                                <br><h3>&nbsp;<b>Mesa Nro : <?php echo e($mesa->numero); ?></b> <a class="btn btn-primary"  href="<?php echo e(url('/sistema/mesas-show')); ?>"><i class="fa fa-search-plus"></i></a></h3>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>   
                    <div class="col-md-3">
                        <label for="">Fecha:</label>
                        <span class="form-control" id="fecha" ></span>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-3 col-md-2">
                        <label for="">Producto:</label>
                        <button id="" type="button" class="btn btn-primary btn-flat btn-block" data-toggle="modal" data-target="#modal-default1" ><span class="fa fa-list"></span> Lista</button>
                    </div>
                </div>
                <table id="tbventas" class="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Codigo</th>
                            <th>Nombre</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Cantidad</th>
                            <th>Importe</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="listaOrden">
                        
                    </tbody>
                </table>
                <br>
                <div class="form-group row">
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon">Subtotal:</span>
                            <input type="text" class="form-control" placeholder="" name="subtotal" readonly="readonly">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon">IGV:</span>
                            <input type="text" class="form-control" placeholder="" name="igv" readonly="readonly">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon">Descuento:</span>
                            <input type="text" class="form-control" placeholder="" name="descuento" value="0.00" readonly="readonly">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon">Total:</span>
                            <input type="text" class="form-control" placeholder="" name="total" readonly="readonly">
                        </div>
                    </div>
                </div>   
            </div>
            <div class="box-footer">
                <div class="col-lg-3"></div>
                <div class="col-lg-6">
                        <div class="form-group">
                            <div class="col-md-12">
                                <button class="btn btn-success btn-flat" onclick="send()">Enviar</button>
                            </div>     
                        </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="col-lg-12">
        <a class="btn btn-primary" href="<?php echo e(url('/sistema/mesas-show')); ?>">Seleccionar Mesa</a>
    </div>
    <?php endif; ?>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sistema.orden.modal-producto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript" src="<?php echo e(url('/js/customs/orden/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/orden/crearF.blade.php ENDPATH**/ ?>