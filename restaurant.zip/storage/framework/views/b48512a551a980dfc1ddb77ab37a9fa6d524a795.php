<?php $__env->startSection('content'); ?>
    <div style="display: none;" >
        vacio
        <div id="formato"></div>
    </div>
     <?php if(!empty($data[0])): ?>
        <div class="container">
            <table  class="table">
                <tr>
                    <th>#</th>
                    <th>MESA</th>
                    <th>ESTADO</th>
                    <th>HORA</th>
                    <th>Imprimir</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td > <b><?php echo e($key+1); ?></b> </td>
                    <td > <b><?php echo e($item->mesa->numero); ?></b> </td>
                    <td > <b><?php echo e($item->estado->nombre); ?></b> </td> 
                    <td > <b><?php echo e($item->fecha); ?></b> </td> 
                    <td ><button id="btn-<?php echo e($item->id); ?>" onclick='imprimir(<?php echo e($item->id); ?>)' class="btn btn-warning">Imprimir orden ID <?php echo e($item->id); ?></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table> 
        </div>
    <?php endif; ?>
           

    <?php echo $__env->make('sistema.chef.modal-descripcion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(url('/js/customs/chef/script.js')); ?>"></script>
<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(url('/js/jQuery.print.js')); ?>"></script><!-- tiene que cargar despues del jquery-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SATELLITE\Documents\GitHub\restaurant\resources\views/sistema/chef/index.blade.php ENDPATH**/ ?>